import QRCodeDisplay from '../admin/QRCodeDisplay';

export default function QRCodeDisplayExample() {
  return <QRCodeDisplay menuUrl="https://example.com/menu" />;
}
