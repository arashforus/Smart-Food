import DashboardStats from '../admin/DashboardStats';

export default function DashboardStatsExample() {
  return <DashboardStats totalItems={9} totalCategories={4} availableItems={9} />;
}
